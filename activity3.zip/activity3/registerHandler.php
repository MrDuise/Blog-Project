
<?php 

//Michael Duisenberg
//09-21-20
//CST-126
//Activity 2 registerion handler page
//connects the register.html page to the server and makes provides error checking to make sure that all data forms have been entered before user is entered into the database



require_once 'myfuncs.php';

if(dbConnect())
{
    $personFirst = addslashes($_POST["firstName"]);
    $personLast = addslashes($_POST["lastName"]);
    $personUserName = addslashes($_POST["userName"]);
    $personPassWord = addslashes($_POST["passWord"]);
}

if($personFirst == NULL){
    echo "The First Name is a required field and cannot be blank";
}

else if ($personLast == NULL){
       echo "The Last Name is a required filed and cannot be blank";
}
else {
    echo "Got the Form <br>";
    echo "First Name is " . $personFirst . "<br>";
    echo "Last Name is " . $personLast . "<br>";
    echo "You are now registered. <br>";
    
    
    
    
    //the following lines create the connection to the database and then test that connection
    
    // Create connection
  
    
    
    
 //the following line enters the data into the database   
    $sql = "INSERT INTO `users` (`ID`, `FIRST_NAME`, `LAST_NAME`, `USERNAME`, `PASSWORD`) VALUES (NULL, '$personFirst', '$personLast', '$personUserName', '$personPassWord')";
    
    
    if (mysqli_query(dbConnect(), $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error(dbConnect());
    }
    
}


?>













