<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



function dbConnect()
{
    
    $host = "localhost";
    $username = "root";
    $password = "root";
    $database_name = "activity1";
    $port = 8889;
    
    $conn = mysqli_connect($host, $username, $password, $database_name, $port);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    return $conn;
}




function saveUserId($id)
{
    session_start();
    $_SESSION["ID"] = $id;
}
function getUserId()
{
    session_start();
    return $_SESSION["ID"];
}
 