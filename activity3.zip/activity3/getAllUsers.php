<?php

$host = "localhost";
$username = "root";
$password = "root";
$database_name = "activity1";
$port = 8889;




// Create connection
$conn = mysqli_connect($host, $username, $password, $database_name, $port);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully <br>";


//The following section of code reads in data from the table in the database
// to the browser instead of reading data from the browser into the database

//read in the ID, first name, and last from the users table
$sql = "SELECT ID, FIRST_NAME, LAST_NAME FROM users";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["ID"]. " - Name: " . $row["FIRST_NAME"]. " " . $row["LAST_NAME"]. "<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);

?>
