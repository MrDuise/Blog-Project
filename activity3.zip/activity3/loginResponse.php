<html>
	<head>
	</head>
		<body>

            <!-- code has a warning becuase variable does not excist in file, but it does excist in loginHandler file, so code works fine -->
			<h2>Login was successful: <?php echo " " . $personUserName ?></h2>
			
			<a href="whoAmI.php">Who Am I</a>
		</body>





</html>
