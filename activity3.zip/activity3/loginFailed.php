<html>
	<head>
	</head>
		<body>

            <!-- code has a warning becuase variable does not excist in file, but it does excist in loginHandler file, so code works fine -->
				<h2><?php echo $message ?></h2>
		</body>





</html>
